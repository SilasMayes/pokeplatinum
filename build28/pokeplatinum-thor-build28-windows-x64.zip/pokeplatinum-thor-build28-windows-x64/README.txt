Pokemon Platinum PC port (Thor fork), build 28 - Windows x64
Source: https://github.com/SilasMayes/pokeplatinum (branch thor-android, commit 02606bee)
        https://github.com/SilasMayes/libntr (branch thor-android, commit 44ea735)

This package contains code only. You need your own dump of Pokemon Platinum (US, CPUE01).

1. Extract this folder anywhere you can write to (the game keeps its files and saves here).
2. Run main.exe. Windows SmartScreen may warn because it is unsigned: More info > Run anyway.
3. On first launch, pick your .nds ROM. Its files are extracted next to the program.


Keyboard (change in Settings > Controls):
    D-pad = arrow keys, A = Z, B = X, X = C, Y = V, L = Q, R = E,
    Start = Enter, Select = Right Shift
    `  (backtick) = settings screen
    Space (hold) / Tab (toggle) = fast-forward
    F1 = Gear full screen (with Settings > Display >
         "Bottom screen in its own window" on)

Licenses for libntr, SDL2, enet and the Atkinson Hyperlegible font are in licenses/.
